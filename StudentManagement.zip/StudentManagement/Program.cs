﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement
{
    delegate T MyDelegate<T>(T a, T b);

    class Student : IComparable
    {
        public Student student;
        public int num; //순번
        public string name; //이름
        public string phone; //전화번호
        public string email; //이메일
        public string sub; //학과
        public int id; //학번
        public string money; //장학금
        public int grade; //학년
        public int score; //성적
        public int bongsa; //봉사시간

        public Student(int num, string name, string phone, string eamil,
            int id, string sub, int grade, string money, int score, int bongsa)
        {
            this.num = num;
            this.name = name;
            this.phone = phone;
            this.email = email;
            this.id = id;
            this.sub = sub;
            this.grade = grade;
            this.money = money;
            this.score = score;
            this.bongsa = bongsa;
        }
     
        public static void personal_info()
        {
        }

        public int CompareTo(object obj)
        {
            throw new NotImplementedException();
        }
        public override string ToString()
        {
            return student.ToString();
        }

       
       
    }
    class Program
    {
        static List<Student> list = new List<Student>();
        private static object Int;

    
        static void Main(string[] args)
        {
            list.Add(new Student(1, "김수지", "010-4164-2608", "oaosuzy@naver.com",
                20150718, "컴퓨터통신무인기술학과", 4, "없음", 3, 120));
            list.Add(new Student(2, "이종현", "010-1234-5678", "jonghyun@naver.com",
                20130649, "컴퓨터통신무인기술학과", 4, "없음", 4, 20));
            list.Add(new Student(3, "손효현", "010-5678-1234", "hihi@naver.com",
                20151234, "컴퓨터통신무인기술학과", 4, "없음", 4, 45));
            list.Add(new Student(4, "김혜인", "010-7890-1234", "hyein@naver.com",
                20155678, "컴퓨터통신무인기술학과", 4, "없음", 3, 70));

            MENU:
            Console.Write("StudentManageMent\n\n");
            Console.WriteLine();
            Console.Write("1.추가\t", "2.검색\t", "3.순위별 출력\t", "4.종료");
            Console.Write("Select Menu : ");
            int input = int.Parse(Console.ReadLine());

            switch(input)
            {
                case 1: //추가
                    Console.WriteLine("추가\n\n");
                    Console.WriteLine("항목을 입력하세요\n");

                    Console.Write("순번 : ");
                    int num = int.Parse(Console.ReadLine());

                    Console.Write("이름 : ");
                    string name = Console.ReadLine();

                    Console.WriteLine("전화번호 : ");
                    string phone = Console.ReadLine();

                    Console.WriteLine("이메일 : ");
                    string email = Console.ReadLine();

                    Console.WriteLine("학번 : ");
                    int id = int.Parse(Console.ReadLine());

                    Console.WriteLine("학과 : ");
                    string sub = Console.ReadLine();

                    Console.WriteLine("학년 : ");
                    int grade = int.Parse(Console.ReadLine());

                    Console.WriteLine("장학금 : ");
                    string money = Console.ReadLine(); 

                    Console.WriteLine("성적 : ");
                    int score = int.Parse(Console.ReadLine());

                    Console.WriteLine("봉사시간 : ");
                    int bongsa = int.Parse(Console.ReadLine());

                    Console.Write("등록하시겠습니까?(y/n)");
                    string answer = Console.ReadLine();
                    if(answer == "y")
                    {
                        Student student = new Student(num, name, phone, email, id, sub, grade, money, score, bongsa);
                        list.Add(student);
                        Console.WriteLine("등록되었습니다!");
                        goto MENU;
                    }

                    if(answer=="n")
                    {
                        goto MENU;
                    }
                    break;

                case 2: //검색

                    SEARCH:
                    Console.WriteLine("검색\n\n");
                    Console.Write("1.학번\t", "2.이름\t", "3.이메일\t");
                    Console.Write("Select Menu : ");
                    int input_2 = int.Parse(Console.ReadLine());

                    if(input_2 == 1)
                    {
                        Console.WriteLine("검색할 학번을 입력하세요:");
                        int input_id = int.Parse(Console.ReadLine());
                      
                        }
                    
                    break;

                case 3: //순위별출력

                    
                    PRINT:
                    Console.WriteLine("순위별출력\n\n");
                    Console.Write("1.학번\t", "2.이름\t", "3.성적\t", "4.봉사시간");
                    Console.Write("Select Menu : ");
                    int input3 = int.Parse(Console.ReadLine());

                    if (input3 ==1 )
                    {
                        list.Sort();
                    }
                    if(input3 ==2)
                    {
                        
                        foreach (var studentname in list)
                        {
                            Console.WriteLine(studentname.name);
                        }
                       
                    }
                    if(input3 == 3)
                    {

                    }

                    if(input3==4)
                    {

                    }


                    break;
            }
        }
       
    }
}

